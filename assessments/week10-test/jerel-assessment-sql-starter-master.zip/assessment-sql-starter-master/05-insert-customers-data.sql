insert into customers (name, contact_email)
values
('Riley Reeves', 'primis.in.faucibus@pellentesqueegetdictum.edu'),
('Jarrod Newman', 'turpis.Aliquam.adipiscing@auctor.ca');
