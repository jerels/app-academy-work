insert into invoices (invoice_number, created_at, paid_on, customer_id)
values
('E0M 3P9', '2019-04-09', '2019-04-30', 1),
('Z1N 0Y0', '2019-04-16', NULL,         2),
('W6Z 1B9', '2019-04-12', '2019-05-15',  2),
('R0T 8A7', '2019-04-29', NULL,         2);
