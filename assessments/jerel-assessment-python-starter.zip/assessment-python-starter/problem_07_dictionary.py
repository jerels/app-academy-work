# DICTIONARY
#
# Write a function named "my_filter" that takes a dictionary as a parameter.
# Return another dictionary that consists of the key/value pairs from the
# argument where the value has a length less than or equal to 3. Use any
# construct that want to implement "my_filter".
#
# Test data follows.

# WRITE YOUR CODE HERE
def my_filter(dit):
    res = {}
    for key in dit:
        if len(dit[key]) <= 3:
            res[key] = dit[key]
    return res


# TEST DATA
print(my_filter({1: ".", 2: "..", 5: "....."}))   # > {1: ".", 2: ".."}
print(my_filter({}))                              # > {}
print(my_filter({1: ".....", 2: "....", 5: ""}))  # > {5: ""}
