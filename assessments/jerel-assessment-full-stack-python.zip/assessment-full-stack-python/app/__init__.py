from flask import Flask, render_template, redirect
from flask_migrate import Migrate
from .forms import NewInstrument
from .config import Configuration
from .models import db, Instrument

app = Flask(__name__)
app.config.from_object(Configuration)
db.init_app(app)
Migrate(app, db)


@app.route('/')
def main():
    return render_template('main_page.html')


@app.route('/new_instrument')
def form():
    return render_template('simple_form.html', form=NewInstrument())


@app.route('/new_instrument', methods=['POST'])
def submit():
    form = NewInstrument()
    if form.validate_on_submit():
        data = form.data
        instrument = Instrument(
            date_bought=data['date_bought'],
            nickname=data['nickname'],
            year=data['year'],
            maker=data['maker'],
            type=data['type'],
            used=data['used'],
        )
        db.session.add(instrument)
        db.session.commit()
        return redirect('/instrument_data')
    else:
        return 'Bad Data'


@app.route('/instrument_data')
def data():
    mInstruments = Instrument.query.filter(
        Instrument.nickname.startswith('M')).all()
    return render_template('simple_form_data.html', instruments=mInstruments)
